/* 
 * File:   buttons.h
 * Author: Tuan
 *
 * Created on October 6, 2019, 6:42 PM
 */

#ifndef BUTTONS_H
#define	BUTTONS_H

#include "config.h"
#include <xc.h>

int readButtonRA5();
int readButtonRB0();
void handleButton(void* data_ptr);

#endif	/* BUTTONS_H */

