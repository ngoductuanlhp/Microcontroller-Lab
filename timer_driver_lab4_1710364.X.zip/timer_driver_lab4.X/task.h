/* 
 * File:   task.h
 * Author: Tuan
 *
 * Created on October 5, 2019, 10:07 PM
 */

#ifndef TASK_H
#define	TASK_H

#include "config.h"
#include "ready_queue.h"
#include <xc.h>

task_struct task_list[MAX_SIZE];
char num_task;
char head;

void initializeTaskList();
char isEmptyList();
char isFullList();
char addTask(tWORD period, tWORD delay, FUNCTION_PTR ptr, void *data);
char removeTask(char idx);
void handleListHead();
void selectReadyTask();

#endif	/* TASK_H */

