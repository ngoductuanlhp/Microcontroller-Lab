/* 
 * File:   mcc.h
 * Author: Tuan
 *
 * Created on October 5, 2019, 9:59 PM
 */

#ifndef MCC_H
#define	MCC_H

#include <xc.h>
#include "clock.h"
#include "lcd.h"
#include "buttons.h"


void system_initialize(void);

#endif	/* MCC_H */

